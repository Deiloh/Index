﻿// Solucionando la tarea en modo básico (low-cost)

// Declaramos un procedimiento (mentira es una función)
// primero la palabra reservada "void"
// segundo el nombre del procedimiento
// tercero un par de ()
// el "cuerpo" (su definición) se escribe en un bloque
/*
void Mostrar10Asteriscos()
{
    for (int i = 0; i < 10; i++)
    {
        Console.Write("*");
    }
}

void Mostrar2AsteriscosDistancia8()
{
    Console.Write("*");
    for (int i = 0; i < 8; i++)
    {
        Console.Write(" ");
    }
    Console.Write("*");
}

void SaltarLinea()
{
    Console.WriteLine();
}

void BorrarPantalla()
{
    Console.Clear();
}

// Este es mi programa principal
BorrarPantalla();
Mostrar10Asteriscos();
SaltarLinea();
for (int i = 0; i < 8; i++)
{
    Mostrar2AsteriscosDistancia8();
    SaltarLinea();
}
Mostrar10Asteriscos();
*/

// Números enteros (int) pseudoaleatorios en C#
// Primero "creamos" un generador de secuencias pseudoaleatorias 
//Random azar = new Random();
// Luego estamos en condiciones de pedir numeritos al azar...
// invocando a azar.Next e indicando el intervalo
// tiramos 5 dados
/*
for (int i = 0; i < 5; i++)
{
    Console.WriteLine($"{azar.Next(1, 7)}");
}
*/
// tiramos un par de dados para ver si hubo suerte
/*
int dado1 = azar.Next(1, 7);
int dado2 = azar.Next(1, 7);

Console.WriteLine($"{dado1}, {dado2}");
if (dado1 == dado2)
{
    Console.WriteLine("Tenés suerte andá al casino");
}
else
{
    Console.WriteLine("Es la vida real, seguí estudiando");
}
*/

// Ajustamos la semilla (seed)
// y con eso controlamos el azar 
// 6861845905873386051800893452274914541926
/*
Random azar = new Random(17); // Indicamos la semilla, me gustó 17
for(int i = 0; i < 40; i++)
{
    Console.Write(azar.Next(0,10));
}
Console.WriteLine();
*/

// Desafíos (tarea) de la primera parte

// Un * que aparece constantemente en posiciones aleatorias
// Un * que avanza siempre un paso en una dirección aleatoria
// un * que avanza "mamado" (en curda, borracho)
// amigo gamba (atajar al mamado)

// Procedimiento parametrizado
// Entre paréntesis ponemos cada uno de los argumentos 
//                          indicando su tipo de dato y su nombre
// En este ejmplito se trata de un entero al que llamamos "n"

// Cuando invocamos un proc. parametrizado, debemos informas los "valores"
//                                          para cada uno de los parámetros
//MostrarElDoble(17); // pasamos el valor 17
//MostrarElDoble(12); // pasamos el valor 12
//MostrarElDoble(); // error porque no informamos ningún valor
//Console.WriteLine(n); // error porque la varibale "n" no está definida en este ámbito
/*
int numero = 89;
MostrarElDoble(numero); // Primero se "evalua" lo que está entre paréntesis 
                        // y ese valor es el que se pasa al procedimiento

MostrarElDoble(1+1);
MostrarElDoble(numero+1);
*/

void MostrarElDoble(int n)
{
    Console.WriteLine($"El doble de {n} es {n*2}");
}

int n = 17;
MostrarElDoble(n);

void Mostrar10Caracteres(char caracter)
{
    for (int i = 0; i < 10; i++)
    {
        Console.Write(caracter);
    }
}

Mostrar10Caracteres('G');

// Procedimiento multiparametrizado
void MostrarEneCaracteres(int cantidad, char caracter)
{
    for (int i = 0; i < cantidad; i++)
    {
        Console.Write(caracter);
    }
}
MostrarEneCaracteres(10, '*');
MostrarEneCaracteres(15, '-');
