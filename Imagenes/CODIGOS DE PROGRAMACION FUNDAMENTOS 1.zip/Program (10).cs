﻿// PARTE II - Batalla naval
/*
const char VACIO = '.';
const char BARCO = 'B';
const char DISPARO = 'X';

char[,] tablero = new char[20, 80];

// para conocer el largo de las dimensiones podemos utilizar la función (método)
// .GetLength(n)   
//            n = 0 -> filas    
//            n = 1 -> columnas
//Console.WriteLine($"Alto:{tablero.GetLength(0)} Ancho:{tablero.GetLength(1)}");
Console.CursorVisible = false;

bool gameOver = false;
int cantDisparos = 0;

LimpiarTablero(tablero);
UbicarBarcos(tablero, 10);
while (!gameOver)
{
    //Console.Clear(); 
    Console.SetCursorPosition(0,0);
    //Disparar(tablero);
    //cantDisparos++;
    Console.Title = $"Disparamos {cantDisparos} veces";
    //TirarBomba(tablero);
    //for (int r = 1; r < 5; r++)
    //    TirarBombaN(tablero, r);
    TirarBombaN(tablero, 10);
    MostrarTablero(tablero);
    Console.ReadKey(true);
    gameOver = barcosActivos(tablero) == 0;
}

void MostrarTablero(char[,] matriz)
{
    for (int f = 0; f < matriz.GetLength(0); f++)
    {
        for (int c = 0; c < matriz.GetLength(1); c++)
        {
            if (matriz[f, c] == VACIO)
                Console.BackgroundColor = ConsoleColor.Blue;
            if (matriz[f, c] == BARCO)
                Console.BackgroundColor = ConsoleColor.Gray;
            if (matriz[f, c] == DISPARO)
                Console.BackgroundColor = ConsoleColor.Red;
                       
            Console.Write(matriz[f, c]);
        }
        Console.WriteLine();
    }
}

void LimpiarTablero(char[,] matriz)
{
    for (int f = 0; f < matriz.GetLength(0); f++)
        for (int c = 0; c < matriz.GetLength(1); c++)
            matriz[f, c] = VACIO;
}

bool UbicarBarcos(char[,] matriz, int cantidad)
{
    Random rng = new Random();

    // TAREA: cotejar que haya espacios vacios sufieintes
    if (matriz.GetLength(0) * matriz.GetLength(1) < cantidad)
        return false;

    while (cantidad-- > 0)
    {
        int fila = rng.Next(0, matriz.GetLength(0));
        int columna = rng.Next(0, matriz.GetLength(1));
        while (!estaVacia(matriz, fila, columna))
        {
            fila = rng.Next(0, matriz.GetLength(0));
            columna = rng.Next(0, matriz.GetLength(1));
        }
        matriz[fila, columna] = BARCO;
    }
    return true;
}

bool estaVacia(char[,] matriz, int fila, int columna)
{
    // Atención que cuenta antes de dispara
    return matriz[fila, columna] == VACIO; 
}

// 1. Función que informe cuántos barcos quedan
int barcosActivos(char[,] matriz)
{
    int contador = 0;
    for (int f = 0; f < matriz.GetLength(0); f++)
    {    
        for (int c = 0; c < matriz.GetLength(1); c++)
        {
            if (matriz[f,c] == BARCO)
                contador++;
        }
    }
    return contador;
}

// 2. Función que informe cuánto espacio queda libre
int espacioLibre(char[,] matriz)
{
    //int resultado;
    //resultado = matriz.GetLength(0) * matriz.GetLength(1) - barcosActivos(matriz);
    //return resultado;
    return matriz.GetLength(0) * matriz.GetLength(1) - barcosActivos(matriz);
}

// 3. Función que dispare al azar
bool Disparar(char[,] matriz)
{
    Random rng = new Random();
    int f = rng.Next(0, matriz.GetLength(0));
    int c = rng.Next(0, matriz.GetLength(1));
    
    bool resultado = matriz[f, c] == BARCO;
    
    matriz[f, c] = DISPARO;
    
    return resultado;
}

//5. Función que dispare bombas de radio 1
bool TirarBomba(char[,] matriz)
{
    Random rng = new Random();
    //int f = rng.Next(0, matriz.GetLength(0));
    //int c = rng.Next(0, matriz.GetLength(1));
    // Trampa para evitar los bordes
    int f = rng.Next(1, matriz.GetLength(0) - 1);
    int c = rng.Next(1, matriz.GetLength(1) - 1);
    
    //bool resultado = matriz[f, c] == BARCO;
    bool resultado = true;
    // Método laborioso. Tarita meter condiconales para que no se rompa
    // la fila de arriba
    matriz[f - 1, c - 1] = DISPARO;
    matriz[f - 1, c    ] = DISPARO;
    matriz[f - 1, c + 1] = DISPARO;
    // la fila del medio
    matriz[f, c - 1] = DISPARO;
    matriz[f, c    ] = DISPARO;
    matriz[f, c + 1] = DISPARO;
    // la fila de abajo
    matriz[f + 1, c - 1] = DISPARO;
    matriz[f + 1, c    ] = DISPARO;
    matriz[f + 1, c + 1] = DISPARO;
    
    const int RADIO = 1;
    // Método de iteracción
    int f_inicio = f - RADIO;
    int c_inicio = c - RADIO;
    int f_fin = f + RADIO;
    int c_fin = c + RADIO;

    for (int fila = f_inicio; fila <= f_fin; fila++)
    {
        for (int columna = c_inicio; columna <= c_fin; columna++)
        {
            matriz[fila, columna] = DISPARO;
        }
    }

    return resultado;
}

//5. Función que dispare bombas de radio 1
bool TirarBombaN(char[,] matriz, int radio)
{
    Random rng = new Random();
    // Trampa para evitar los bordes
    int f = rng.Next(radio, matriz.GetLength(0) - radio);
    int c = rng.Next(radio, matriz.GetLength(1) - radio);
    
    bool resultado = true;
    
    // Método de iteracción
    int f_inicio = f - radio;
    int c_inicio = c - radio;
    int f_fin = f + radio;
    int c_fin = c + radio;

    for (int fila = f_inicio; fila <= f_fin; fila++)
    {
        for (int columna = c_inicio; columna <= c_fin; columna++)
        {
            if (Distancia(f, c, fila, columna) < radio)
                matriz[fila, columna] = DISPARO;
        }
    }

    return resultado;
}


/* 
TAREA:
1. Función que informe cuántos barcos quedan
2. Función que informe cuánto espacio queda libre
3. Función que dispare al azar 
4. Ciclo que dispare hasta hundir todos los barcos

Bonus track (04/06):
4.1 Metemos un contador de disparos
4.2 Mostramos donde dispara

5. Función que dispare bombas de radio 1
6. Función que dispare bombas de rario n

AYUDA:
La distancia la sacamos con ayuda de Pitágoras
la raiz cuadrada de la suma de los lados al cuadrado
*/

//int x1 = 0; int y1 = 0;

//int x2 = 10; int y2 = 0;
// La función "Math.Sqrt(n)" devuelve la raiz cuadrada del número n
//Console.WriteLine(Distancia(x1, y1, x2, y2));
// La clase que viene vemos los tipos de datos float y double


using System.Security;

double Distancia(int x1, int y1, int x2, int y2)
{
    int lado_a = y2 - y1;
    int lado_b = x2 - x1;
    return Math.Sqrt(lado_a * lado_a + lado_b * lado_b);
}

/* 
TAREA:
Un personaje se mueve por la pantalla usando las teclas del curor
Y se muestra a cada paso la distancia al origen (0,0)
*/
Random rng = new Random();

// Skin del player
const char SKIN = '@';
// posicion del jugador
// inicialemnte está en el origen (0, 0)
int player_x = 0;
int player_y = 0; 

// Skin del enemigo
const char ENEMY_SKIN = 'E';
// posición enemigo
// atenti que podríamos qiedar abajo del enemigo o este muy cerca nuestro
int enemy_x = ColumnaRandom();
int enemy_y = FilaRandom();

bool gameOver = false;

while (!gameOver)
{
    Console.Clear();

    // Mostramos el player
    Console.SetCursorPosition(player_x, player_y);
    Console.Write(SKIN);
    Console.Title = $"Distancia:{Distancia(0, 0, player_x, player_y)}";

    Console.SetCursorPosition(enemy_x, enemy_y);
    
    if (Distancia(player_x, player_y, enemy_x, enemy_y) <= 5)
        Console.BackgroundColor = ConsoleColor.Red;
    Console.Write(ENEMY_SKIN);

    Console.BackgroundColor = ConsoleColor.Black;

    ConsoleKey tecla = Console.ReadKey(true).Key;

    if (tecla == ConsoleKey.Escape)
        gameOver = true;
    // si no tocás nada, el destino es el mismo lugar donde estás
    int x_destino = player_x;
    int y_destino = player_y;
    // Según la tecla calculamos el destino
    if (tecla == ConsoleKey.LeftArrow) x_destino = player_x - 1;
    if (tecla == ConsoleKey.RightArrow) x_destino = player_x + 1;
    if (tecla == ConsoleKey.UpArrow) y_destino = player_y - 1;
    if (tecla == ConsoleKey.DownArrow) y_destino = player_y + 1;
    // Si el destino está en los confines de la pantalla, movemos al player
    if (x_destino >= 0 && x_destino < Console.WindowWidth)
        player_x = x_destino;
    if (y_destino >= 0 && y_destino < Console.WindowHeight)
        player_y = y_destino;
    // revisar implementación de clases pasadas usando delta_x

    // Mostramos la distancia al origen
    
}

int FilaRandom()
{
    return rng.Next(0, Console.WindowHeight);
}

int ColumnaRandom()
{
    return rng.Next(0, Console.WindowWidth);
}

// Tareas colectivas:
/*
1. Teleport player (a coordenas al azar cuando tocamos [T]) Gus
2. Que el enemigo te mate (Gonzalo). Quita un punto de vida y se apartan ambos al azar
3. Sistema de salud. Inicialmente 3 (Milagros) 
4. Dash (tocando flechas + [SHIFT]) (Mauro)
5. Un arma en pantalla (al inventario) (Kevin)
6. Sistema de inventario (Gabriel)
7. Si está armado, el enemigo escapa en lugar de seguirte (Gus)
8. Si estás en el radio de visión del enemigo, te persigue
9. El enemigo patrulla (en horizontal (der <-> izq), un rango) (Lautaro) ++
10. El enemigo patrulla (en reloj de cuartos de hora un rango) (Lautaro/Gus) +++
11. Si conseguis 1 moneda ($) ganás. Bonus track (n-monedas) +++
12. Si estás armado y tocás al enemigo, ganás
13. Si encontras botiquín (B) recuperas salud a full 
14. Todo en colores 
*/