﻿// Clase 10 - Matrices
// En esta materia utilizaremos siempre matrices bidimensionales (2D)
// 
/*
const char VACIO = '.';

// Declarar e inicializar una matriz
char[,] grilla = new char[3, 3];

Random rng = new Random();

LimpiarGrilla(grilla);

bool gameOver = false;
int turno = 0;
while (!gameOver)
{
    Console.Clear();
    // elijo coordenadas al azar
    int fila = rng.Next(0, 3);
    int columna = rng.Next(0, 3);
    while (!estaVacia(grilla, fila, columna))
    {
        fila = rng.Next(0, 3);
        columna = rng.Next(0, 3);
    }
    // Alternamos los turnos
    if (turno == 0)
    {
        grilla[fila, columna] = 'X';
        turno = 1;
    }
    else
    {
        grilla[fila, columna] = 'O';
        turno = 0;
    }
    MostrarGrilla(grilla);
    Console.WriteLine();
    gameOver = !hayEspacio(grilla) || cualquierFilaCompleta(grilla);
    Console.ReadKey(true);
}

MostrarGrilla(grilla);


void MostrarGrilla( char[,] matriz)
{
    for (int f = 0; f < 3; f++)
    {
        for (int c = 0; c < 3; c++)
        {
            Console.Write(matriz[f, c]);
        }
        Console.WriteLine();
    }
}

void LimpiarGrilla(char[,] matriz)
{
    for (int f = 0; f < 3; f++)
        for (int c = 0; c < 3; c++)
            matriz[f, c] = VACIO;    
}

bool hayEspacio(char[,] matriz)
{
    //bool respuesta = false;

    for (int f = 0; f < 3; f++)
        for (int c = 0; c < 3; c++)
            if (matriz[f, c] == VACIO)
                return true;
    //respuesta = true;
    //return respuesta;
    return false;
}

bool estaVacia(char[,] matriz, int fila, int columna)
{
    return matriz[fila, columna] == VACIO;
}

bool filaCompleta(char[,] matriz, int fila)
{
    return (matriz[fila, 0] == matriz[fila, 1] &&
            matriz[fila, 1] == matriz[fila, 2] &&
            matriz[fila, 0] != VACIO);
}

bool cualquierFilaCompleta(char[,] matriz)
{
    for (int fila = 0; fila < 3; fila++)
        if (filaCompleta(matriz, fila))
            return true;
    return false;
}
*/
/*
TAREA:
1. Verificar final por columna o por diagonales  (mínimo)
2. Que informe ganador (deseable/mńimo)
3. Que funcione interactivo (Humano vs. CPU) ++
4. Que la compu aproveche situaciones ganadoras (Nivel II)
5. Que la compu empate/gane siempre (Nivel IV)
*/

// PARTE II - Batalla naval
using System.Security.Cryptography.X509Certificates;

const char VACIO = '.';
char[,] tablero = new char[10, 10];

// para conocer el largo de las dimensiones podemos utilizar la función (método)
// .GetLength(n)   
//            n = 0 -> filas    
//            n = 1 -> columnas
//Console.WriteLine($"Alto:{tablero.GetLength(0)} Ancho:{tablero.GetLength(1)}");
//bool gameOver = false;

//LimpiarTablero(tablero);
//UbicarBarcos(tablero, 10);
//while (!gameOver)
//{
//    MostrarTablero(tablero);
//    Console.ReadKey(true);
//}

void MostrarTablero( char[,] matriz)
{
    for (int f = 0; f < matriz.GetLength(0); f++)
    {
        for (int c = 0; c < matriz.GetLength(1); c++)
        {
            Console.Write(matriz[f, c]);
        }
        Console.WriteLine();
    }
}

void LimpiarTablero(char[,] matriz)
{
    for (int f = 0; f < matriz.GetLength(0); f++)
        for (int c = 0; c < matriz.GetLength(1); c++)
            matriz[f, c] = VACIO;
}

bool UbicarBarcos(char[,] matriz, int cantidad)
{
    Random rng = new Random();

    // TAREA: cotejar que haya espacios vacios sufieintes
    if (matriz.GetLength(0) * matriz.GetLength(1) < cantidad)
        return false;

    while (cantidad-- > 0)
    {
        int fila = rng.Next(0, matriz.GetLength(0));
        int columna = rng.Next(0, matriz.GetLength(1));
        while (!estaVacia(matriz, fila, columna))
        {
            fila = rng.Next(0, matriz.GetLength(0));
            columna = rng.Next(0, matriz.GetLength(1));
        }
        matriz[fila, columna] = 'B';
    }
    return true;
}

bool estaVacia(char[,] matriz, int fila, int columna)
{
    return matriz[fila, columna] == VACIO;
}

/* 
TAREA:
1. Función que informe cuántos barcos quedan
2. Función que informe cuánto espacio queda libre
3. Función que dispare al azar 
4. Ciclo que dispare hasta hundir todos los barcos
5. Función que dispare bombas de radio 1
6. Función que dispare bombas de rario n

AYUDA:
La distancia la sacamos con ayuda de Pitágoras
la raiz cuadrada de la suma de los lados al cuadrado
*/
int x1 = 0; int y1 = 0;

int x2 = 10; int y2 = 0;
// La función "Math.Sqrt(n)" devuelve la raiz cuadrada del número n
Console.WriteLine(Distancia(x1, y1, x2, y2));
// La clase que viene vemos los tipos de datos float y double
double Distancia(int x1, int y1, int x2, int y2)
{
    int lado_a = y2 - y1;
    int lado_b = x2 - x1;
    return Math.Sqrt(lado_a * lado_a + lado_b * lado_b);
}

/* 
TAREA:
Un personaje se mueve por la pantalla usando las teclas del curor
Y se muestra a cada paso la distancia al origen (0,0)
*/

/* ATENCIÓN:

NO VAMOS MUY PERO MUY TEMPRANO, QUEDA EL COMPROMISO DE ESTUDIAR A FULL

                        José C. Paz, 20 de mayo de 2025 20:43
*/