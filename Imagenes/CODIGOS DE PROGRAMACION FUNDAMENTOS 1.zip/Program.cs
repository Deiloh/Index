﻿Console.WriteLine("Hola Manola");
Console.WriteLine("Adios");
Console.WriteLine($"1+2={1+2});
