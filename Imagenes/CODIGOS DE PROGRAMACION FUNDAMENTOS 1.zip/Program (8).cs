﻿char[] objetos = { 'P', 'O', 'D', 'N', 'M' };

char ObjetoAlAzar(char[] objetos)
{
    Random rng = new Random();
    return objetos[rng.Next(0, objetos.Length)];
}

char[] inventario = new char[9];

void CargarInventario(char[] inventario, char[] objetos)
{
    for (int i = 0; i < inventario.Length; i++)
    {
        inventario[i] = ObjetoAlAzar(objetos);
    }
}

void MostrarInventario(char[] inventario)
{
    Console.Write("Inventario: ");
    for (int i = 0; i < inventario.Length; i++)
    {
        Console.Write($"{inventario[i]} ");
    }
    Console.WriteLine();
}

int CuantoHay(char[] inventario, char objeto)
{
    int cantidad = 0;
    for (int i = 0; i < inventario.Length; i++)
    {
        if (inventario[i] == objeto)
        {
            cantidad++;
        }
    }
    return cantidad;
}

void EliminarObjeto(char[] inventario, char objeto)
{
    int i = 0;
    while (inventario[i] != objeto && i < inventario.Length)
    {
        i++;
    }
    inventario[i] = ' ';
}

void EliminarObjetos(char[] inventario, char objeto, int cantidad)
{
    for (int i = 0; i < cantidad; i++)
    {
        EliminarObjeto(inventario, objeto);
    }
}

void AgregarObjeto(char[]inventario, char objeto)
{
    int i = 0;
    while (inventario[i] != ' ')
    {
        i++;
    }
    inventario[i] = objeto;
}
/*
1 = Espada de Oro: 1 Palo + 2 Lingotes de Oro
2 = Espada de Diamante: 1 Palo + 2 Diamantes
3 = Espada de Netherita: 1 Espada de Diamante + 1 Netherita
4 = Manzana Dorada: 1 Manzana + 8 Lingotes de Oro
*/
//Console.WriteLine(ObjetoAlAzar(objetos));
CargarInventario(inventario, objetos);
MostrarInventario(inventario);
// ¿estamos en condiciones de craftear una Espada de Oro?
// 1 (P)alo y 2 (O)ros
//Console.WriteLine(CuantoHay(inventario, 'P'));
//Console.WriteLine(CuantoHay(inventario, 'O'));
/*
int cantOro = CuantoHay(inventario, 'O');
int cantPalo = CuantoHay(inventario, 'P');

if (cantPalo >= 1 && cantOro >= 2)
{
    Console.WriteLine("Podemos craftear una espada de oro");
    EliminarObjeto(inventario, 'P');
    EliminarObjetos(inventario, 'O', 2);
    AgregarObjeto(inventario, '1');
}
*/
// Espadad de Diamante
if (CuantoHay(inventario, 'P') >= 1 && CuantoHay(inventario, 'D') >= 2)
{
    Console.WriteLine("Podemos craftear una espada de diamante");
    EliminarObjeto(inventario, 'P');
    EliminarObjetos(inventario, 'D', 2);
    AgregarObjeto(inventario, '2');
}
MostrarInventario(inventario);
// Espada de Netherita
if (CuantoHay(inventario, '2') >= 1 && CuantoHay(inventario, 'N') >= 1)
{
    Console.WriteLine("Podemos craftear una espada de netherita");
    EliminarObjeto(inventario, '2');
    EliminarObjeto(inventario, 'N');
    AgregarObjeto(inventario, '3');
}
MostrarInventario(inventario);
