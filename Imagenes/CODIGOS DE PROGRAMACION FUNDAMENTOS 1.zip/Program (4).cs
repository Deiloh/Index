﻿// Práctica

// Si no tenemos "for"
/*
int c = 0;
while(c < 10)
{
    Console.Write("+");
    c++;
}
Console.ReadKey();
*/

// Estructura de repetición fija
// La estructura "for" tiene tres partes
// 1ra. se ejecuta sólo una vez
// 2da. se evalúa en cada iteración (vuelta)
// 3ra. se ejcuta al término de cada iteración
//for (int i = 0; i < 10; i++)
//{
//    Console.WriteLine($"{i} +");
//}


// Declaramos un procedimiento (mentira es una función)
// primero la palabra reservada "void"
// segundo el nombre del procedimiento
// tercero un par de ()
// el "cuerpo" (su definición) se escribe en un bloque
void Mostrar10Asteriscos()
{
    for (int i = 0; i < 10; i++)
    {
        Console.Write("*");
    }
}

Console.Clear();
// Para invocar al procedimiento utilizamos su nombre con ()
for (int i= 0; i< 10; i++)
{
    Mostrar10Asteriscos();
    Console.WriteLine();
}

/*
//Console.WriteLine(i); //atenti que no existe fuera del ámbito (context) donde fué declarada

// 0. Inicialización 
Console.ReadKey();


// Declaramos  las variables 
int posX;
int posY;
bool juegoEnCurso;

ConsoleKey teclaPulsada;

ConsoleColor colorFondo = ConsoleColor.Cyan;
ConsoleColor colorFrente = ConsoleColor.Blue;

// Definición de constantes (palabra reservada "const")
const char apariencia = 'A';

juegoEnCurso = true; // Esta es la "condición de entrada" al ciclo de repe.

// Ubicamos al personaje en el centro de la pantalla
posX = Console.WindowWidth / 2;
posY = Console.WindowHeight / 2;

Console.CursorVisible = false;
int desX;       // las usaremos para referir al destino en cada eje
int desY;

// 1. Ciclo principal del juego
//while (juegoEnCurso == true) // Rendundante porque la expresión es SIEMPRE igual a juegoEnCurso
while (juegoEnCurso)
{
    
    // 1. Mostramos la pantalla
    Console.BackgroundColor = colorFondo;
    Console.ForegroundColor = colorFrente;
    Console.Clear();
    Console.Write($"posX:{posX}, posY:{posY}");
    Console.SetCursorPosition(posX, posY);
    Console.Write(apariencia);

    // 2. Leemos la entrada
    teclaPulsada = Console.ReadKey(true).Key;
    // 2.1 Tratamos las difrenctes teclas
    if (teclaPulsada == ConsoleKey.Q)
    {
        juegoEnCurso = false;
    }
    desX = posX;
    desY = posY;
    if (teclaPulsada == ConsoleKey.RightArrow)
    {
        desX = posX + 1;
    }
    if (teclaPulsada == ConsoleKey.LeftArrow)
    {
        desX = posX -1;
    }
    /*
    // Control de rango (corralito)
    if (desX >= 0 & desX < Console.WindowWidth)
    {
        posX = desX;
    }
    */
  /*
    // pegamos la vuelta
    if (desX == Console.WindowWidth)
    {    
        desX = 0;
    }
    if (desX == -1)
    {    
        desX = Console.WindowWidth -1;
    }
    posX = desX;
}

Console.ResetColor();
Console.Clear();
Console.WriteLine("Gracias por jugar");
*/
