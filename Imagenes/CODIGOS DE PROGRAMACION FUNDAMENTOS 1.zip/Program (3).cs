﻿//Console.BackgroundColor = ConsoleColor.Cyan;
Console.Clear();
// Desafío argento
/*
Console.BackgroundColor = ConsoleColor.DarkBlue;
Console.ForegroundColor = ConsoleColor.White;
Console.Write("ARG");

Console.BackgroundColor = ConsoleColor.White;
Console.ForegroundColor = ConsoleColor.DarkBlue;
Console.Write("ENT");

Console.BackgroundColor = ConsoleColor.DarkBlue;
Console.ForegroundColor = ConsoleColor.White;
Console.Write("INA");
*/

// Desafío tamaño
/*
Console.WriteLine("Dimensiones de la pantalla");
Console.WriteLine($"Ancho:{Console.WindowWidth}");
Console.WriteLine($"Alto:{Console.WindowHeight}");
*/

//Console.SetCursorPosition(10, 1);
//Console.WriteLine("Hola");

// Desafío coordenadas
/*
Console.BackgroundColor = ConsoleColor.DarkBlue;
Console.ForegroundColor = ConsoleColor.White;
Console.Clear();
Console.SetCursorPosition(0, 0);
Console.Write("1");

int ancho = Console.WindowWidth;
int alto = Console.WindowHeight;

Console.SetCursorPosition(ancho - 1, 0);
Console.Write("2");

Console.SetCursorPosition(0, alto - 1);
Console.Write("3");

Console.SetCursorPosition(ancho - 1, alto - 1);
Console.Write("4");

Console.SetCursorPosition(ancho / 2, alto / 2);
Console.Write("5");
*/


//Console.WriteLine("Ingresá la contraseña");
/*
int contador = -1;

// Ciclo de repetición condicional
// la palabrita reservada en C es "while"
// la condición se escribe como siempre, entre ()
// Funciona así: }
//  1. Se evalua la expresión
//  2. Si se muestra V, se ejecuta el bloque
//     Se retorna al punto 1 
while (contador >= 0);
{    
    Console.WriteLine($"Contador:{contador}");
    contador = contador - 1;
}

Console.WriteLine("Salimos de ciclo");
Console.WriteLine($"Contador:{contador}");
*/

bool juegoEnCurso = true;
int vidas = 3;
ConsoleKey tecla;

Console.WriteLine("Inicio del juego");

while (juegoEnCurso) 
{
    Console.WriteLine("[M] Te mata, [Q] Fin del juego");
    
    tecla = Console.ReadKey(true).Key; // Esta función me retorna la tecla oprimida
                                   // el dato es de "tipo" ConsoleKey
    if (tecla == ConsoleKey.M)
    {
        Console.WriteLine("Perdiste una vida... que pena");
        vidas--;
        juegoEnCurso = vidas > 0;
    }
    if (tecla == ConsoleKey.Q)
    {
        Console.WriteLine("Abandonaste");
        juegoEnCurso = false;
    }
}
Console.WriteLine("Fin del juego");


//Console.ReadKey();

