﻿// Arreglos unidimensionales (Vectores)

// Declaración y creación de un arreglo
// tipo de dato, [], identificador (nombre), = new, tipo de dato, [longitud]
//
// ejemplo letras
//char[] letras = new char[]; // el motivo se explica en fundamentos II

//letras[0] = 'A';
//letras[1] = 'B';
//letras[2] = 'B';
//letras[3] = 'A';
//letras[4] = 'Z';

//int i = 1;
//Console.WriteLine(letras[i]);

//for (int i = 0; i < 5; i++)
//{
//    Console.WriteLine(letras[i]);
//}

//Console.WriteLine($"Longitud del arreglo={letras.Length}");
//for (int i = 0; i < letras.Length; i++)
//{
//    Console.WriteLine(letras[i]);
//}
/*
// Ejemplito timbero
int[] cubilete = new int[5];

LanzarDados(cubilete);
MostrarElementos(cubilete);
int suma = SumarElementos(cubilete);
Console.WriteLine($"La suma es: {suma}");

// decalrar vectores de manera implicita (por extensión)
//char[] puntos = {'N', 'S', 'E', 'O'};
int[] puntos = {200, 400, 800, 1600};

MostrarElementos(puntos);
Console.WriteLine($"Ganaste:{SumarElementos(puntos)}");

void LanzarDados(int[] dados)
{
    Random rng = new Random();

    for (int i = 0; i < dados.Length; i++)
    {
        dados[i] = rng.Next(1, 7);
    }
}

void MostrarElementos(int[] elementos)
{
    for (int i = 0; i < elementos.Length; i++)
    {
        Console.Write($"{elementos[i]} ");
    }
    Console.WriteLine();
}

int SumarElementos(int[] elementos)
{
    int suma = 0;
    for (int i = 0; i < elementos.Length; i++)
    {
        suma += elementos[i];
    }
    return suma;
}
*/

// Desafío "inventario"
// existen tres tipos de items:
//  '$' = Dinero,  'A' = Munición,  '+' = Medicina
//
// El inventario tiene lugar para n items,
// se puede tomar un item (si hay lugar)
// se puede dejar un item (indicando la posicion del mismo)
// se puede consular si hay un tipo de item indicando el tipo ('$', 'A' o '+')
//                   el resultdo es la ubicación del item o (-1) indicando que no hay
//
// Problema: crear un inventario y llenarlo con items de manera aleatoria.

char[] inventario = new char[6];
char[] items = {'$', 'A', '+'};

CrearInventario(inventario, items);
MostrarInventario(inventario);
Console.WriteLine($"Hay $: {HayItem(inventario, '$')}");
Console.WriteLine($"Hay $: {DondeHayItem(inventario, '$')}");
Console.WriteLine($"Hay A: {DondeHayItem(inventario, 'A')}");
Console.WriteLine($"Hay +: {DondeHayItem(inventario, '+')}");

// Gastar toda la guita
DejarItems(inventario, '$');

//DejarItem(inventario, 33); // Bolonqui atajado
MostrarInventario(inventario);

// Gastar toda la merca
DejarItems(inventario, '+');
MostrarInventario(inventario);

// Procedimeinto CrearInventario
//   Llena el inventario con items elegidos al azar
void CrearInventario(char[] inventario, char[] items)
{
    Random rng = new Random();
    
    for (int i = 0; i < inventario.Length; i++)
    {
        inventario[i] = items[rng.Next(0, items.Length)];
        /*
        int destino = rng.Next(0, 2);
        if (destino == 1)
            inventario[i] = '$';
        if (destino == 2)
            inventario[i] = 'A';
        if (destino == 3)
            inventario[i] = '+';
        */
    }
}

void MostrarInventario(char[] inventario)
{
    Console.Write("Inventario: |");
    for (int i = 0; i < inventario.Length; i++)
    {
        Console.Write($"{inventario[i]}|");
    }
    Console.WriteLine();
}

bool HayItem(char[] inventario, char item)
{
    bool respuesta = false;
    /*
    for (int i = 0; i < inventario.Length; i++)
    {
        if (inventario[i] == item)
        {
            respuesta = true;
        }    
    }
    */
    int i = 0;
    while (i < inventario.Length && respuesta == false)
    {    
        if (inventario[i] == item)
        {
            respuesta = true;
        }
        i++;    
    }    
    return respuesta;
    // Tarea para el hogar (mostrar las iteraciones y confirmar los dos modos de funcionamiento)
}

int DondeHayItem(char[] inventario, char item)
{
    int ubicacion = -1;
    int i = 0;
    while (i < inventario.Length && ubicacion == -1)
    {    
        if (inventario[i] == item)
        {
            ubicacion = i;
        }
        i++;    
    }    
    return ubicacion;
    // Tarea para el hogar: estudiar esta función detenidamente
}
void DejarItem(char[] inventario, int ubicacion)
{
    if (ubicacion >= 0 && ubicacion < inventario.Length)
    {
        inventario[ubicacion] = ' ';
    }
}

void DejarItems(char[] inventario, char item)
{
    // Mientras haya items de ese tipo (item) seguimos repitiendo
    while (HayItem(inventario, item))
    {
        // Para cada uno, dejamos el item
        int ubicacion = DondeHayItem(inventario, item); // esta es la ubicación
        DejarItem(inventario, ubicacion);
    }
}

// Alternativa Gonzalo
void DejarItems2(char[] inventario, char item)
{
    // Mientras haya items de ese tipo (item) seguimos repitiendo
    for (int i = 0; i < inventario.Length; i++)
    {
        if (inventario[i] == item)
            inventario[i] = ' ';
    }
}


// tareitas:

// TomarItem
// Le damos un inventario y un item. Si hay lugar lo toma, caso contrario retorna false

// CambiarItems
// Le damos un inventario y un item origen y otro destino
// ejemplito: compra municion origen = '$' destino = 'A'
//            compra medicina origen = '$' destino = '+'
// Bonus track: compra con costo doble.
//              dejar 2 unidades de un tipo de item y gana una de otro tipo