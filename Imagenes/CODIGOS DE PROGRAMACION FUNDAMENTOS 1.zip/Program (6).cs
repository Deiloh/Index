﻿// recibe dos valores (ancho y alto)
// elige unas coordenadas al azar (dentro de la pantalla)
// e imprime un asterisco (*)
void PonerAsterisco(int alto, int ancho)
{
    Random azar = new Random(); // La explicamos en Funda II

    int x = azar.Next(0, ancho);
    int y = azar.Next(0, alto);
    
    Console.SetCursorPosition(x, y);
    Console.Write("*");
}
// elige un color al azar
// las posibilidades son Rojo, Verde y Azul
//
void AjustarColor()
{
    Random azar = new Random();
    int numColor = azar.Next(0, 16);
    ConsoleColor color = ConsoleColor.Black;
    // Un auténtico muestrario de estilos, no lo hagan en sus casas
    if (numColor == 0) { 
        color = ConsoleColor.Red;  
    }
    
    if (numColor == 1)
    { 
        color = ConsoleColor.Green;
    }
    
    if (numColor == 2) { color = ConsoleColor.Blue; }

    Console.ForegroundColor = color;
}
/*

  PROGRAMA PRINCIPAL

*/
Console.CursorVisible = false;
Console.Clear();
//while (true)
//{
//    PonerAsterisco(10, 10);
//    Console.ReadKey(true);
//}
/*for (int i = 0; i < 1000; i++)
{
    AjustarColor();
    PonerAsterisco(Console.WindowHeight, Console.WindowWidth);
}
Console.ReadKey();
*/
/*
while (true)
{
    AjustarColor();
    PonerAsterisco(Console.WindowHeight, Console.WindowWidth);
}
*/
/*
int x = Console.WindowWidth / 2;
int y = Console.WindowHeight / 2;
Console.Clear();
while (true)
{
    Random azar = new Random();

    
    Console.SetCursorPosition(x, y);
    Console.Write("*");

    // Estrategia de puntos cardinales
    // 0 = Norte, 1 = Este, 2 = Sur y 3 = Oeste
    int dx = 0;
    int dy = 0;

    //int numPunto = azar.Next(0, 4);
    //if (numPunto == 0) { dx =  0; dy = -1; }
    //if (numPunto == 1) { dx =  1; dy =  0; }
    //if (numPunto == 2) { dx =  0; dy =  1; }
    //if (numPunto == 3) { dx = -1; dy =  0; }

    // Vamos con rangos en 8 direcciones y quietos/as
    //dx = azar.Next(-1, 2);
    //dy = azar.Next(-1, 2);

    // Ahora nos proponemos que no salgan al mismo tiempo dx = y dy = 0
    while (dx == 0 && dy == 0)
    {
        dx = azar.Next(-1, 2);
        dy = azar.Next(-1, 2);

        if (dx == 0 && dy == 0)
            AjustarColor();
    }
    // Atenti que nos podemos ir de la pantalla
    // Controlamos x
    x = x + dx;
    
    if (x < 0)
        x = Console.WindowWidth - 1;
    if (x > Console.WindowWidth - 1)
        x = 0;
    
    y = y + dy;
    
    if (y < 0)
        y = Console.WindowHeight -1;
    if (y > Console.WindowHeight - 1)
        y = 0;            
    
    Console.ReadKey(true);
}
*/

// Rutinas v2.0

// Procedimeintos
void MostrarDoble(int n)
{
    Console.WriteLine(n * 2);
}

MostrarDoble(17);

// Funciones
// Siempre se indica el tipo de la función (el tipo de dato del valor que retorna)
int Doble(int n)  // Declaración
{
    //return n * 2; // Definición (implementación)
    return n + n;
}

// Para invocar un afunción (evluarla) simplemente escribimos su nombre (y argumentos) 
Console.WriteLine(Doble(2));

int original = 17;
int doble = Doble(original);

Console.WriteLine($"ori:{original} doble:{doble}");


while(true)
{
    Console.BackgroundColor = ColorAlAzar();
    Console.Clear();
    Console.ReadKey();
}

// Una función que me retorna un color al azar (desde un conjunto limitado)
ConsoleColor ColorAlAzar()
{
    Random azar = new Random();
    int numColor = azar.Next(0, 3);
    
    ConsoleColor color = ConsoleColor.White;

    if (numColor == 0) { color = ConsoleColor.Red;  }
    if (numColor == 1) { color = ConsoleColor.Green; }
    if (numColor == 2) { color = ConsoleColor.Blue;  }

    return color;
}