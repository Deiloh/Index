﻿// Declarar una variable de tipo lógico (booleano)
//bool TieneLaLlave;
//bool EstaFrenteAlCofre;
//bool Visible;

//Asignar (inicializar) la variable
//TieneLaLlave = true; // "true" o "false" 
//EstaFrenteAlCofre = true;

// Mostramos (usamos/referimos) las variables
// Atenti que por consola salen en con la primera letra en mayúscula
//Console.WriteLine($"Tenemos la llave: {TieneLaLlave}");
//Console.WriteLine($"Estamos frente al cofre: {EstaFrenteAlCofre}");

// Veamos la operación "negación", "no", "!", "not"
//Console.WriteLine($"Tenemos la llave: {!TieneLaLlave}");

// Una forma de comentarios multilínea

/*
Visible = false;
Console.WriteLine($"Visible:{Visible}");
Visible = !Visible;
Console.WriteLine($"Visible:{Visible}");
Visible = !Visible;
Console.WriteLine($"Visible:{Visible}");
*/

// Ahora vamos con la "conjunción", "y", "&", "and"
/*
bool AbreElCofre;

AbreElCofre = TieneLaLlave & EstaFrenteAlCofre;
Console.WriteLine($"Abre el cofre: {AbreElCofre}");
*/
// Ejemplito de "disyunción", "o", "|", "or" 
/*
bool LlaveVerde = true;
bool LlaveMaestra = true;

bool AbreLaCajaFuerte = LlaveVerde | LlaveMaestra;
Console.WriteLine($"Abre: {AbreLaCajaFuerte}");
*/

// Estructura condicional (Muerte el "IF")

// Condicional simple
bool TieneArma = true;
bool TieneBalas = false;

bool PuedeDisparar = TieneArma & TieneBalas;

// "if" (expresión lógica que opera como condición) 
// { bloque de código}

if (PuedeDisparar)
{
    Console.WriteLine("Miedo");
}
// Un ejemplito de uso del operador negación
if (!PuedeDisparar)
{
    Console.WriteLine("Sigue la joda");
}
// Alternativa condicional (si se cumple toma el camino A, caso contrario toma el camino B)
// Los caminos (flujo de ejecución) son mutuamente excluyentes
if (PuedeDisparar)
{
    // Camino A
    Console.WriteLine("Puede disparar");
}
else
{
    // Camino B
    Console.WriteLine("No puede disparar");
}

// podemos "meter" una expresión lógica directamente
// if (TieneArma & TieneBalas)

// Operadores relacionales
// Implica comparar elementos ordenables

/*

Operadores:
 ">" mayor
 "==" igual
 "<" menor
 "!=" distinto
 "<=" menor "o" igual
 ">=" mayor "o" igual

int CantidadDeBalas = 10;

if (CantidadDeBalas > 0)
{
    Console.WriteLine("Puede disparar");
}
*/

int choclos = 23;

//if (choclos >= 25)
if (choclos == 25 | choclos > 25)
{
    Console.WriteLine("Hay suficiente choclo");
}
else
{
    Console.WriteLine("No hay choclos");
}