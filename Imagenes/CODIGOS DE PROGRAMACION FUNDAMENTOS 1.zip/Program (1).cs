﻿// 1. Declaración (operación)
//    Forma general: Tipo Separador Identificador (Nombre)

// variables enteras, el tipo es "int"

int Vidas;          // Vidas = "indefinido"

// 2. Asignación (operación) 
//Vidas = 3;     // Usando un literal
Vidas = 2+1;     // Usando una expresión    Vidas = 3

// 3. Uso o referencia (operación)
Console.WriteLine($"Te quedan {Vidas} vidas");

// 4. Asignaciones (Parte II), "La posta"
Vidas = Vidas - 1; //                       Vidas = 2
Console.WriteLine($"Te quedan {Vidas} vidas");

// 5. Inicialización (Declaramos y asignamos)
int Nivel = 1;          // Nivel = 1
//int Nivel = 3;

// Funciones de las variables
// variable como contador. Cambia en una unidad, la operación se llama "incremento"
Nivel = Nivel + 1;      // Nivel = 2

Nivel ++;                // Nivel = 3
Nivel--;                // Nivel = 2

Console.WriteLine($"Estamos en el nivel {Nivel}");

// varaible como acumulador

int Puntos = 0;
// 400, 800, 1600, 3200
//

int NumeroDeFantasma = 1;

// Morfamos un fantasma
Puntos = Puntos + 400 * NumeroDeFantasma;
Console.WriteLine($"Puntos:{Puntos}");
// Actualizamos el número de fantasmas morfados
NumeroDeFantasma = NumeroDeFantasma + 1;

// Morfamos otro fantasma y
Puntos = Puntos + 400 * NumeroDeFantasma++;
Console.WriteLine($"Puntos:{Puntos}");

// Morfamos otro fantasma y
Puntos = Puntos + 400 * NumeroDeFantasma;
Console.WriteLine($"Puntos:{Puntos}");
// Morfamos otro fantasma
Puntos = Puntos + 400 * NumeroDeFantasma;
Console.WriteLine($"Puntos:{Puntos}");



// variable como bandera  (Suspenso hasta más tarde)
//      Hola 9 de abril